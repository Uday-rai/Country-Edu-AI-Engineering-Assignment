# Resume Screening and Candidate Ranking System

FastAPI project for uploading resumes, extracting candidate details, ranking candidates against a job description, filtering results, and exporting a shortlist.

## Run

```powershell
cd "D:\Country Edu\Uday\Question_1_Resume_Screening_System"
..\ .venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open:

- Dashboard: `http://127.0.0.1:8000/dashboard/?v=3`
- Swagger docs: `http://127.0.0.1:8000/docs`

## Features

- PDF and DOCX resume upload
- Candidate extraction: name, email, phone, skills, education, experience, certifications
- Job description based scoring
- Candidate ranking
- Skill and experience filtering
- CSV shortlist export
- Interview question generation

## Main Endpoints

- `GET /health`
- `POST /job-description`
- `POST /resumes`
- `GET /candidates`
- `GET /candidates/filter`
- `GET /export/shortlist`
- `GET /candidates/{candidate_id}/interview-questions`

## Sample Data

Sample resumes are available in `sample_data/`.

