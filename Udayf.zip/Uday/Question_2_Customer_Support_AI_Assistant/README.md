# Customer Support Knowledge Base Assistant

FastAPI project for uploading company documents and answering support questions using the uploaded knowledge base. If the system cannot find enough supporting information, it returns `I don't know` and creates an escalation.

## Run

```powershell
cd "D:\Country Edu\Uday\Question_2_Customer_Support_AI_Assistant"
..\ .venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8010
```

Open:

- Assistant UI: `http://127.0.0.1:8010/assistant`
- Swagger docs: `http://127.0.0.1:8010/docs`

## Features

- PDF, DOCX and TXT knowledge base upload
- Document parsing and chunking
- Retrieval-based answer generation
- Conversation history by session
- Escalation for unanswered queries

## Main Endpoints

- `GET /health`
- `POST /documents/upload`
- `POST /chat`
- `GET /sessions/{session_id}/history`
- `GET /escalations`

## Sample Data

Use `sample_data/faq.txt` for a quick demo.

